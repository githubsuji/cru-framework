package com.pto.cru.constants;

public class WebSiteURL {

	public static final String SELENIUM_PRACTICE_WEBSITE = "https://chandanachaitanya.github.io/selenium-practice-site/";
	public static final String AUTOMATION_PRACTICE_WEBSITE_URL = "http://automationpractice.com/index.php";
	public static final String JQUERY_CONTEXTMENU_WEBSITE_URL = "http://swisnl.github.io/jQuery-contextMenu/demo.html";
	public static final String MOUSE_DOUBLECLICK_PRACTICE_SITE_URL = "https://api.jquery.com/dblclick/";
	public static final String DRAG_DROP_PRACTICE_SITE_URL = "http://jqueryui.com/droppable/";
	public static final String FILE_UPLOAD_PRACTICE_SITE_URL = "http://demo.guru99.com/test/image_upload/index.php";
	

}
