package com.pto.cru.tests.mouseactionpractice;

import org.openqa.selenium.Alert;
import org.testng.annotations.Test;

import com.pto.cru.constants.WebSiteURL;
import com.pto.cru.framework.BaseTest;
import com.pto.cru.tests.steps.mouseactionpractice.MouseActionPracticeTestSteps;
import com.pto.cru.util.WaitUtil;

import lombok.extern.slf4j.Slf4j;
// https://www.selenium.dev/selenium/docs/api/java/org/openqa/selenium/interactions/Actions.html
@Slf4j
public class MouseActionPracticeTest extends BaseTest {
	private MouseActionPracticeTestSteps mapTestSteps = new MouseActionPracticeTestSteps();
	
	@Test
	public void mouseOverMenuClickTestcase() {
		log.info("mouseOverMenuClickTest case execution started");
		mapTestSteps.openWebsite(WebSiteURL.AUTOMATION_PRACTICE_WEBSITE_URL);
		mapTestSteps.mouseOverToWomenMenu();
		mapTestSteps.clickOnMouseOveredTshirtMenu();
		mapTestSteps.verifyTshirtPage();
		log.info("mouseOverMenuClickTest case execution completed");
	}
	
	@Test
	public void contextMenuClickTestcase() {
		log.info("contextMenuClickTestcase case execution started");
		mapTestSteps.openWebsite(WebSiteURL.JQUERY_CONTEXTMENU_WEBSITE_URL);
		mapTestSteps.openContextMenu();
		mapTestSteps.clickOnQuitMenu();
		Alert alert = mapTestSteps.verifyAlertContent();
		mapTestSteps.closeAlert(alert);
		log.info("contextMenuClickTestcase case execution completed");
	}
	
	@Test
	public void mouseDoubleClickTestcase() {
		log.info("mouseDoubleClickTestcase case execution started");
		mapTestSteps.openWebsite(WebSiteURL.MOUSE_DOUBLECLICK_PRACTICE_SITE_URL);
		WaitUtil.applyWait(1000);
		mapTestSteps.scrollToIframe();	
		mapTestSteps.switchToDoubleClickContextIframe();
		mapTestSteps.performMouseDoubleClick();	
		mapTestSteps.verifyDoubleClicked();
		log.info("mouseDoubleClickTestcase case execution completed");
	}
	
	@Test
	public  void dragAndDropTestcase() {
		log.info("dragAndDropTestcase case execution started");
		mapTestSteps.openWebsite(WebSiteURL.DRAG_DROP_PRACTICE_SITE_URL);
		WaitUtil.applyWait(1000);
		mapTestSteps.scrollToIframe();	
		mapTestSteps.switchToDragAndDropContextIframe();
		mapTestSteps.performDragAndDrop();
		mapTestSteps.verifyDragAndDrop();
		log.info("dragAndDropTestcase case execution completed");
	}
}
