package com.pto.cru.appcontext.threadlocal;

public class AppThreadLocal {
	public static final ThreadLocal<AppContext> appThreadLocal = new ThreadLocal<AppContext>();

	public static void set(AppContext context) {
		
		
		appThreadLocal.set(context);
	}

	public static void unset() {
		appThreadLocal.remove();
	}

	public static AppContext get() {
		return (AppContext) appThreadLocal.get();
	}
}
