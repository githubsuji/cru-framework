package com.pto.cru.config.data;

import lombok.Data;

@Data
public class EnvSpecificTestConfig {
	
	private String websiteDomain;
	private String screenshotPath;
	private EmailData emailCredentials;
	private String testDataLocation;
	private boolean screenshotEnabledFlag;
	private boolean emailEnabledFlag;


}
