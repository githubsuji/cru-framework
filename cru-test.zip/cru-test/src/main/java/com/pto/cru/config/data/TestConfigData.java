package com.pto.cru.config.data;

import lombok.Data;

@Data
public class TestConfigData {

	private WebsiteDomains websiteDomains;
	private ScreenShotpath screenshotPath;
	private EmailCredentials emailCredentials;
	private TestDataLocation testDataLocation;
	private boolean screenshotEnabledFlag;
	private boolean emailEnabledFlag;

//	public static void main(String[] args) {
//		javaTojson();
//	}
//
//	private static void javaTojson() {
//		TestConfigData tcd = new TestConfigData();
//
//		WebsiteDomains wd = new WebsiteDomains();
//		wd.setDev("http://ust-global.dev.com");
//		wd.setPerf("http://ust-global.perf.com");
//		wd.setProd("http://ust-global.prod.com");
//		wd.setSit("http://ust-global.sit.com");
//		ScreenShotpath ssp = new  ScreenShotpath();
//		tcd.setWebsiteDomains(wd);
//		tcd.setScreenshotPath(ssp);
//
//		
//		// Creating Object of ObjectMapper define in Jakson Api
//		ObjectMapper Obj = new ObjectMapper();
//
//		try {
//
//			// get Oraganisation object as a json string
//			String jsonStr = Obj.writeValueAsString(tcd);
//
//			// Displaying JSON String
//			System.out.println(jsonStr);
//		}
//
//		catch (IOException e) {
//			e.printStackTrace();
//		}
//	}

}
