package com.pto.cru.framework;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class BrowserScrollWindow {
	
	public static void scrollToBottomByJavascript() {
		JavascriptExecutor js = ((JavascriptExecutor) Browser.driver);
		js.executeScript("scroll(0, 250);");
	}
	public static void scrollToBottomByKeys() {
		Browser.driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL, Keys.END);

	}
	
	public static void scrollIntoWebElement(WebElement ele) {
		JavascriptExecutor js = ((JavascriptExecutor) Browser.driver);
		js.executeScript("arguments[0].scrollIntoView();", ele);
		 
	}
	
	public static void scrollUpByKeyUpCount(int count) {
		for (int i = 0; i < count; i++) {
			Actions action = new Actions(Browser.driver);
			action.sendKeys(Keys.PAGE_UP).build().perform();
		}
		
	}

}
