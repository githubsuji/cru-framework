package com.pto.cru.listeners;

public class TestngListener extends TestCaseMethodListener {

}