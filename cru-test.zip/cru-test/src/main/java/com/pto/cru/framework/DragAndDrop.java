package com.pto.cru.framework;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class DragAndDrop {
	
	public static void doDragAndDrop(WebElement sourceElem, WebElement targetElem) {
		Actions actions = new Actions(Browser.driver);
		actions.dragAndDrop(sourceElem, targetElem).perform();

	}

}
