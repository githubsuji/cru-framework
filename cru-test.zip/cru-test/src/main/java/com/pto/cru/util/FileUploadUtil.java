package com.pto.cru.util;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import org.sikuli.script.FindFailed;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FileUploadUtil {
	
	public static void uploadFileByRobot(String uploadImagePath) {
		try {
			Robot robot = new Robot();
			 robot.setAutoDelay(2000);
			 
		        StringSelection selection = new StringSelection(uploadImagePath);
		        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection,null);
		 
		        robot.setAutoDelay(1000);
		 
		        robot.keyPress(KeyEvent.VK_CONTROL);
		        robot.keyPress(KeyEvent.VK_V);
		 
		        robot.keyRelease(KeyEvent.VK_CONTROL);
		        robot.keyRelease(KeyEvent.VK_V);
		 
		        robot.setAutoDelay(1000);
		 
		        robot.keyPress(KeyEvent.VK_ENTER);
		        robot.keyRelease(KeyEvent.VK_ENTER);
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void fileuploadBySikuli(String sikuliImagesPath, String uploadImagePath) {
		 Screen screen = new Screen();
		 Pattern fileInputTextBox = new Pattern(sikuliImagesPath + "File-TextBox.PNG");
		 Pattern openButton = new Pattern(sikuliImagesPath + "Open-Button.PNG");		 
		 try {
			 screen.wait(fileInputTextBox, 20);
			 screen.type(fileInputTextBox, uploadImagePath);
			 screen.click(openButton);
		} catch (FindFailed e) {
			log.error("Error occured while uploading {}", e);
		}
	}
}
