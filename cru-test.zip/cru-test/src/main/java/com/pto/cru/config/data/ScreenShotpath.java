package com.pto.cru.config.data;

import lombok.Data;

@Data
public class ScreenShotpath {
	  private String dev;
	  private String perf;
	  private String prod;
	  private String sit;
}
