package com.pto.cru.listeners;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import org.testng.IExecutionListener;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.io.CharStreams;
import com.pto.cru.appcontext.threadlocal.AppContext;
import com.pto.cru.appcontext.threadlocal.AppThreadLocal;
import com.pto.cru.config.data.EnvSpecificTestConfig;
import com.pto.cru.config.data.ScreenShotpath;
import com.pto.cru.config.data.TestConfigData;
import com.pto.cru.config.data.WebsiteDomains;
import com.pto.cru.framework.Browser;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TestNgExecutionListener implements IExecutionListener{
	private static final String DEFAULT_CONFIG_FILE = "test-config.json";
	@Override
	public void onExecutionStart() { 
	this.initAppThreadLocalAndAppcontext();
	log.info("TestNG is going to start testConfigJsonFile: {}  environment: {}", System.getProperty("testConfigJsonFile"), System.getProperty("env"));
	TestConfigData testConfigData = this.loadTheTestConfigFile();
	this.loadEnvSpecificDataToTestContext(testConfigData);
	} 
	 
	/** creating global data context across all classes corresponding to Thread */
	private void initAppThreadLocalAndAppcontext() {
		AppContext appCtxt =  new AppContext();
		AppThreadLocal.set(appCtxt);

	}
	
	@Override
	public void onExecutionFinish() { 
		log.info("TestNG is finished"); 
	}
	
	private TestConfigData loadTheTestConfigFile() {
		String testConfigJsonFile = null;
		TestConfigData testConfigData = null;
		//InputStream jsonInputStream = null;
		try {
			testConfigJsonFile = System.getProperty("testConfigJsonFile");
		} catch (Exception e) {
			log.error(" Test ConfigJson File Location not found. {}", e);
			
		}
		if(null != testConfigJsonFile) {
			log.info(" Test ConfigJson File Location found. {} ", testConfigJsonFile);
		}else {
			testConfigJsonFile = DEFAULT_CONFIG_FILE;
			log.warn(" Test ConfigJson File Location not found. System will continue testing with default config file.");
		}
		
		try {
			//jsonInputStream = new FileInputStream(new File(testConfigJsonFile));
		File configJsonFile =	new File(testConfigJsonFile);
		testConfigData = convertConfigJsonToTestConfigJavaObj(configJsonFile);
		this.javaTojson(testConfigData);
			//this.printConfigFileContent(jsonInputStream);
			
		} catch (Exception e) {
			log.error("Config File not found {}", e);
			log.warn("Config File not found");
		}
		return testConfigData;
	}
	
	private void printConfigFileContent(InputStream jsonInputStream) {
		String text = null;
	    try (Reader reader = new InputStreamReader(jsonInputStream)) {
	        text = CharStreams.toString(reader);
	        log.info(text);
	    } catch (IOException e) {
			log.error("Config File not readable {}", e);
			log.warn("Config File not readable");
		}

	}
	private TestConfigData convertConfigJsonToTestConfigJavaObj(File configJsonFile) {
		log.info("Parsing data from json and converting it into TestConfigData object");
		ObjectMapper mapper = new ObjectMapper();
		TestConfigData testConfigData = null;
		try {
			testConfigData	= mapper.readValue(configJsonFile, TestConfigData.class);
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		log.info("Parsing and data conversion completed");
		return testConfigData;
	}
	private  void javaTojson(TestConfigData tcd) {
		log.info("Printing parsed json data from TestConfigData object");
		// Creating Object of ObjectMapper define in Jakson Api
		ObjectMapper Obj = new ObjectMapper();

		try {

			// get Oraganisation object as a json string
			String jsonStr = Obj.writeValueAsString(tcd);

			// Displaying JSON String
			log.info("loaded json config {} ", jsonStr);
		}

		catch (IOException e) {
			e.printStackTrace();
		}
	}
	private void loadEnvSpecificDataToTestContext(TestConfigData testConfigData) {
		
		String environment = System.getProperty("env");
		if(null != environment) {
		switch (environment) {
		case "dev":
			this.loadDevSpecifiTestConfig(testConfigData);
			break;

		default:
			this.loadDevSpecifiTestConfig(testConfigData);
			break;
		}
		}else {
			log.warn("Environment variable 'env' is null");
		}
	}

	private void loadDevSpecifiTestConfig(TestConfigData testConfigData) {
		EnvSpecificTestConfig envSpecificTestConfig = new EnvSpecificTestConfig();
		envSpecificTestConfig.setWebsiteDomain(testConfigData.getWebsiteDomains().getDev());
		envSpecificTestConfig.setScreenshotPath(testConfigData.getScreenshotPath().getDev());
		envSpecificTestConfig.setTestDataLocation(testConfigData.getTestDataLocation().getDev());
		envSpecificTestConfig.setEmailCredentials(testConfigData.getEmailCredentials().getDev());
		envSpecificTestConfig.setEmailEnabledFlag(testConfigData.isEmailEnabledFlag());
		envSpecificTestConfig.setScreenshotEnabledFlag(testConfigData.isScreenshotEnabledFlag());
		//System.setProperty("envSpecificTestConfig", envSpecificTestConfig);
		// Setting data to a global variable to make it available across all classes corresponding to Test Execution
		Browser.envSpecificTestConfig = envSpecificTestConfig;
		
		// Way 2 - Setting data to a global variable to make it available across all classes corresponding to Test Execution		
		AppThreadLocal.get().getContextData().put("envSpecificTestConfig", envSpecificTestConfig);
		
	}
}
