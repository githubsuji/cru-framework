package com.pto.cru.config.data;

import lombok.Data;

@Data
public class EmailCredentials {
	private EmailData dev;
	private EmailData perf;
	private EmailData prod;
	private EmailData sit;

}
