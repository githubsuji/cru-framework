package com.pto.cru.appcontext.threadlocal;

import java.util.HashMap;
import java.util.Map;

public class AppContext {
	private  final Map<String, Object> contextData = new HashMap<>();

	public Map<String, Object> getContextData() {
		return contextData;
	}
}
