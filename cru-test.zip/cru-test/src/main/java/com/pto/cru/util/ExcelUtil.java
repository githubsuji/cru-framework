package com.pto.cru.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ExcelUtil {

	public static Workbook getExcelWorkBook(String filePath) {
		log.info("Loading Excel file from {} into Java Memory has been started. ", filePath);
		InputStream excelInputStream = null;
		Workbook workbook = null;

		try {
			excelInputStream = new FileInputStream(new File(filePath));
			log.info("Excel file from {} successfull loaded into Java Memory", filePath);
			workbook = WorkbookFactory.create(excelInputStream);
	        workbook.setMissingCellPolicy(MissingCellPolicy.RETURN_BLANK_AS_NULL);

		} catch (IOException e) {
			log.error("Error while loading excel file into Java Memory {}", e);
		}
		return workbook;
	}
	
	

}
