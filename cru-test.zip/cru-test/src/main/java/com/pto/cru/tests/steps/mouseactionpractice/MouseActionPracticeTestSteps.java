package com.pto.cru.tests.steps.mouseactionpractice;

import static org.junit.Assert.assertTrue;
import static org.testng.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.pto.cru.framework.Browser;
import com.pto.cru.framework.BrowserScrollWindow;
import com.pto.cru.framework.DragAndDrop;
import com.pto.cru.tests.pageobjects.mouseactionpractice.AutomationPracticeHomePage;
import com.pto.cru.util.WaitUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class MouseActionPracticeTestSteps {
	private AutomationPracticeHomePage aphPageObj = new AutomationPracticeHomePage();
	public  void openWebsite(String url) {
		
		Browser.driver.get(url);
		
	}

	public  void mouseOverToWomenMenu() {
		WebElement womenMenuEle = aphPageObj.getWomenMenu();
		aphPageObj.mouseOverWomenMenu(womenMenuEle);
		
//		FluentWait<WebDriver> wait = WaitUtil.explicitWaitByFluentWait(10, 2);
//		WebElement womenMenuEle = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"block_top_menu\"]/ul/li[1]/a")));
//		Actions actions =  new Actions(Browser.driver);
//		actions.moveToElement(womenMenuEle).perform();
		
	}

	public  void clickOnMouseOveredTshirtMenu() {
		WebElement tShirtSubMenu = aphPageObj.getTShirtSubMenu();
		aphPageObj.clickOnTShirtSubMenu(tShirtSubMenu);
//		FluentWait<WebDriver> wait = WaitUtil.explicitWaitByFluentWait(10, 2);		
//		WebElement tShirtSubMenu = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"block_top_menu\"]/ul/li[1]/ul/li[1]/ul/li[1]/a")));
//		Actions actions =  new Actions(Browser.driver);
//		actions.moveToElement(tShirtSubMenu).perform();
//		actions.click().build().perform();
		
	}

	public  void verifyTshirtPage() {
		WebElement tshirtMainMenu  = aphPageObj.getTShirtMainMenu();
//		FluentWait<WebDriver> wait = WaitUtil.explicitWaitByFluentWait(10, 2);	
//		WebElement tshirtMainMenu = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"block_top_menu\"]/ul/li[3]/a")));
		verifyMenuIsSelected(tshirtMainMenu);
	}
	private  void verifyMenuIsSelected(WebElement tshirtMainMenu) {
		String actualBackgroundColor = aphPageObj.getTshirtMainMenuBackground(tshirtMainMenu); 
		String expectedBackgroundColor = "rgb(51, 51, 51)"; // RGB value (#333333) // https://www.rapidtables.com/convert/color/hex-to-rgb.html
		log.info("Actual background Color {} , expectedBackgroundColor {}", actualBackgroundColor, expectedBackgroundColor);
		assertTrue(actualBackgroundColor.contains(expectedBackgroundColor));
	}

	public  void openContextMenu() {
		FluentWait<WebDriver> wait = WaitUtil.explicitWaitByFluentWait(10, 2);	
		WebElement rightClickMeButton = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".context-menu-one.btn.btn-neutral")));
		Actions actions =  new Actions(Browser.driver);
		actions.moveToElement(rightClickMeButton);
		actions.contextClick().build().perform();
	}

	public  void clickOnQuitMenu() {
		FluentWait<WebDriver> wait = WaitUtil.explicitWaitByFluentWait(10, 2);	
		WebElement quitMenu = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".context-menu-item.context-menu-icon.context-menu-icon-quit")));
		Actions actions =  new Actions(Browser.driver);
		actions.moveToElement(quitMenu).click().build().perform();
	}

	public  Alert verifyAlertContent() {
		FluentWait<WebDriver> wait = WaitUtil.explicitWaitByFluentWait(10, 2);	
		Alert alert =  wait.until(ExpectedConditions.alertIsPresent());
		String alertMsg = alert.getText();
		String expectedMsg = "clicked: quit";
		assertEquals(alertMsg, expectedMsg);
		return alert;
	}

	public  void closeAlert(Alert alert) {
		alert.accept();
	}

	public  void performMouseDoubleClick() {
		FluentWait<WebDriver> wait = WaitUtil.explicitWaitByFluentWait(10, 2);	
		WebElement doubleClickContext = wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("div")));
		Actions actions =  new Actions(Browser.driver);
		actions.moveToElement(doubleClickContext).doubleClick().build().perform();
	}

	public  void scrollToIframe() {
		FluentWait<WebDriver> wait = WaitUtil.explicitWaitByFluentWait(10, 2);	
		WebElement iframe = wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("iframe"))); 
		BrowserScrollWindow.scrollIntoWebElement(iframe);
	}

	public  void switchToDoubleClickContextIframe() {
		switchToIframeByTagNameLocator();
	}

	public  void verifyDoubleClicked() {
		FluentWait<WebDriver> wait = WaitUtil.explicitWaitByFluentWait(10, 2);	
		WebElement doubleClickContext = wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("div")));
		String className = doubleClickContext.getAttribute("class");
		assertEquals(className, "dbl");
	}

	public  void switchToDragAndDropContextIframe() {
		switchToIframeByTagNameLocator();
	}
	
	private  void switchToIframeByTagNameLocator() {
		FluentWait<WebDriver> wait = WaitUtil.explicitWaitByFluentWait(10, 2);
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.tagName("iframe")));
	}

	public  void performDragAndDrop() {
		FluentWait<WebDriver> wait = WaitUtil.explicitWaitByFluentWait(10, 2);
		WebElement sourceElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("draggable")));
		WebElement targetElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("droppable")));
		DragAndDrop.doDragAndDrop(sourceElement, targetElement);
		
	}

	public  void verifyDragAndDrop() {
		FluentWait<WebDriver> wait = WaitUtil.explicitWaitByFluentWait(10, 2);
		WebElement pElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("#droppable p")));
		String pInnerText = pElement.getAttribute("innerText");
		assertEquals(pInnerText, "Dropped!");
		
		
	}
	

}
