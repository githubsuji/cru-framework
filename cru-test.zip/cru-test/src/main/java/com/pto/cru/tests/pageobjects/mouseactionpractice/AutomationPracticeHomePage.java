package com.pto.cru.tests.pageobjects.mouseactionpractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.pto.cru.framework.Browser;
import com.pto.cru.util.WaitUtil;

public class AutomationPracticeHomePage {
	
	
	private By womenMenuEleLocator = By.xpath("//*[@id=\"block_top_menu\"]/ul/li[1]/a");
	private By tShirtSubMenu = By.xpath("//*[@id=\"block_top_menu\"]/ul/li[1]/ul/li[1]/ul/li[1]/a");
	private By tshirtMainMenu = By.xpath("//*[@id=\"block_top_menu\"]/ul/li[3]/a");
	

    public WebElement getWomenMenu() {
    	FluentWait<WebDriver> wait = WaitUtil.explicitWaitByFluentWait(10, 2);
		WebElement womenMenuEle = wait.until(ExpectedConditions.presenceOfElementLocated(this.womenMenuEleLocator));
		return womenMenuEle;
    }
    public void mouseOverWomenMenu(WebElement womenMenuEle) {
    	Actions actions =  new Actions(Browser.driver);
		actions.moveToElement(womenMenuEle).perform();
    }
	public WebElement getTShirtSubMenu() {
		FluentWait<WebDriver> wait = WaitUtil.explicitWaitByFluentWait(10, 2);		
		WebElement tShirtSubMenu = wait.until(ExpectedConditions.elementToBeClickable(this.tShirtSubMenu));
		return tShirtSubMenu;
	}
	public void clickOnTShirtSubMenu(WebElement tShirtSubMenu) {
		Actions actions =  new Actions(Browser.driver);
		actions.moveToElement(tShirtSubMenu).perform();
		actions.click().build().perform();
	}
	public  WebElement getTShirtMainMenu() {
		FluentWait<WebDriver> wait = WaitUtil.explicitWaitByFluentWait(10, 2);	
		WebElement tshirtMainMenu = wait.until(ExpectedConditions.elementToBeClickable(this.tshirtMainMenu));
		return tshirtMainMenu;
	}
	public String getTshirtMainMenuBackground(WebElement tshirtMainMenu) {
		
		return tshirtMainMenu.getCssValue("background");
	}
}
