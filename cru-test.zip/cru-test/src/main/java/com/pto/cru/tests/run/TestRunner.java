package com.pto.cru.tests.run;

import java.util.ArrayList;
import java.util.List;


import org.testng.TestNG;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TestRunner {
	private static final String DEFAULT_MASTER_SUITE_FILE = "C:\\Users\\sujit\\eclipse-workspace-chinnu-batch\\cru-test\\src\\main\\resources\\test-suites\\master-testsuite.xml";
	//final static Logger log = LoggerFactory.getLogger(TestRunner.class);
	public static void main(String[] args) {
     log.info("Inside Test Runner");
        String mastersuitePath =  getMasterSuitePath();
     // read json file ---> xml path
		TestNG tng = new TestNG();
		
		List<String> suites = new ArrayList<String>();
		// List<String> suites = Lists.newArrayList();
		//suites.add("master-testsuite.xml");
		suites.add(mastersuitePath);
		tng.setTestSuites(suites);
		 tng.run();
	 log.info("End of Test Runner");
	     
	}
	
	private static String getMasterSuitePath() {
		
		String mastersuitePath =  null;
		try {
			mastersuitePath =	System.getProperty("surefire.suiteXmlFiles");
		} catch (Exception e) {
			log.warn("There is no mastersuite file path found. System will be using default - hardcoded path for test suite files");
		}
		log.info("Master suite file path:  {} ", mastersuitePath);
		return mastersuitePath != null ? mastersuitePath : DEFAULT_MASTER_SUITE_FILE;
				
	}
	/*
	Realtime Test Execution Commands: 

Way-1 [Using maven Surefire plugin ]
mvn test -Dsurefire.suiteXmlFiles=D:\Automation\test-suites\master-testsuite.xml -DtestConfigJsonFile=D:\Automation\config\test-config.json


Way-2 [Using Java Command ]
step-1 - build the application from its root directory - in command prompt
           mvn clean install -DskipTests=true
step -2 copy cru-test-app-1.0.0-fat-tests.jar from target folder and paste it into the directory where you want to run it 

step - 3 rename it as cru-test-app-1.0.0.jar
step 4 - from commandline run below command
java -Dsurefire.suiteXmlFiles=D:\Automation\test-suites\master-testsuite.xml -DtestConfigJsonFile=D:\Automation\config\test-config.json -jar cru-test-app-1.0.0.jar
*/

}
