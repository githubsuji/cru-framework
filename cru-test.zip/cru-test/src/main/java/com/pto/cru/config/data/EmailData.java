package com.pto.cru.config.data;

import lombok.Data;

@Data
public class EmailData {
	
	private String emailId;
	private String password;

}
